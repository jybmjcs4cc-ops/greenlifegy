# Roadmap

- [x] Change cart icon, drawer accents, and checkout button to the site's mint accent.
- [ ] Activate cash on delivery and Visa in Shopify checkout — requires merchant payment settings access and a supported card provider.

- [x] Add company details: GreenLife Plastics, address (Cairo - Tenth of Ramadan 3rd Industrial Zone A5), phones (+20 114 1766700, +20 114 1889985), Instagram (greenlife_plastics)
- [x] Show each phone number on its own line, aligned/tidy (contact page + footer)
- [ ] Confirm real email, working hours, and which number is on WhatsApp (still shows "coming soon")
- [ ] Store connects, but it has 0 products — waiting on user to add products or confirm the right store
- [x] Apply palette 4 (charcoal + mint) to the store for preview; keep the picker available for comparisons
