<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

# AGENTS.md

- Storefront uses the Shopify Storefront API (2026-10) client-side via `src/lib/shopify.ts`; cart state lives in `src/stores/cartStore.ts` (zustand persist) and checkout always goes through the cart's `checkoutUrl` with `channel=online_store`, never manual URLs.
- Bilingual UI: all copy goes through `src/lib/i18n.ts` dictionaries (ar default RTL, en LTR); page direction is set client-side in `LangEffects`. Company contact data is centralized in `src/lib/company.ts`.
- Products come from Shopify only (no mocks); empty catalog renders an empty state, products are created in Shopify with the user's real names/prices.
