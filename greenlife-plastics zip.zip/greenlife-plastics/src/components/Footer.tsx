import { Link } from "@tanstack/react-router";
import { Mail, MapPin, Phone, Clock, Instagram, Facebook } from "lucide-react";
import { company } from "@/lib/company";
import { useT, useLang } from "@/lib/i18n";

export function Footer() {
  const t = useT();
  const lang = useLang();

  return (
    <footer className="mt-16 border-t bg-secondary/50">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-3">
        <div>
          <h3 className="font-display text-lg font-bold">{company.name[lang]}</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            {company.address[lang] || t.contact.missing}
          </p>
        </div>

        <div>
          <h4 className="font-semibold">{t.footer.quickLinks}</h4>
          <ul className="mt-2 space-y-1.5 text-sm">
            <li>
              <Link to="/" className="text-muted-foreground hover:text-foreground">
                {t.nav.home}
              </Link>
            </li>
            <li>
              <Link to="/products" className="text-muted-foreground hover:text-foreground">
                {t.nav.products}
              </Link>
            </li>
            <li>
              <Link to="/contact" className="text-muted-foreground hover:text-foreground">
                {t.nav.contact}
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-semibold">{t.footer.contactUs}</h4>
          <ul className="mt-2 space-y-2 text-sm text-muted-foreground">
            <li className="flex items-center gap-2">
              <Mail className="h-4 w-4 shrink-0" />
              {company.email ? <span dir="ltr">{company.email}</span> : t.contact.missing}
            </li>
            <li className="flex items-start gap-2">
              <Phone className="mt-0.5 h-4 w-4 shrink-0" />
              <span className="flex flex-col gap-0.5">
                {company.phones.length > 0
                  ? company.phones.map((phone) => (
                      <a
                        key={phone}
                        href={`tel:${phone.replace(/[\s()-]/g, "")}`}
                        dir="ltr"
                        className="tabular-nums hover:text-foreground hover:underline"
                      >
                        {phone}
                      </a>
                    ))
                  : t.contact.missing}
              </span>
            </li>
            <li className="flex items-center gap-2">
              <MapPin className="h-4 w-4 shrink-0" />
              {company.address[lang] || t.contact.missing}
            </li>
            <li className="flex items-center gap-2">
              <Clock className="h-4 w-4 shrink-0" />
              {company.hours[lang] || t.contact.missing}
            </li>
            {company.instagram && (
              <li className="flex items-center gap-2">
                <Instagram className="h-4 w-4 shrink-0" />
                <a
                  href={`https://www.instagram.com/${company.instagram}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-foreground hover:underline"
                >
                  <span dir="ltr">@{company.instagram}</span>
                </a>
              </li>
            )}
            <li className="flex items-center gap-2">
              <Facebook className="h-4 w-4 shrink-0" />
              <a
                href={company.facebook.url}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-foreground hover:underline"
              >
                <span dir="ltr">{company.facebook.name}</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t py-4 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} {company.name[lang]} — {t.footer.rights}
      </div>
    </footer>
  );
}
