import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { CartDrawer } from "@/components/CartDrawer";
import { Languages } from "lucide-react";
import { Logo } from "@/components/Logo";
import { useT, useLang, useLangStore } from "@/lib/i18n";

export function Header() {
  const t = useT();
  const lang = useLang();
  const setLang = useLangStore((s) => s.setLang);

  const navItems = [
    { to: "/", label: t.nav.home },
    { to: "/products", label: t.nav.products },
    { to: "/contact", label: t.nav.contact },
  ] as const;

  return (
    <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
      <div className="h-1 w-full bg-accent" />
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3 sm:px-6">
        <Link to="/" className="flex items-center gap-2">
          <Logo />
        </Link>

        <nav className="mx-auto flex items-center gap-1 sm:gap-2">
          {navItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="rounded-md px-3 py-2 text-sm font-medium text-foreground/80 transition-colors hover:bg-secondary hover:text-foreground"
              activeProps={{ className: "bg-secondary text-foreground font-semibold" }}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLang(lang === "ar" ? "en" : "ar")}
            className="gap-1.5 font-semibold"
          >
            <Languages className="h-4 w-4" />
            {t.langLabel}
          </Button>
          <CartDrawer />
        </div>
      </div>
    </header>
  );
}
