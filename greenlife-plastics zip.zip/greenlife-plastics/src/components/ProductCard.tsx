import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { useCartStore } from "@/stores/cartStore";
import { formatPrice, type ShopifyProduct } from "@/lib/shopify";
import { useT, useLang } from "@/lib/i18n";
import { toast } from "sonner";
import { Loader2, ShoppingCart } from "lucide-react";

export function ProductCard({ product }: { product: ShopifyProduct }) {
  const t = useT();
  const lang = useLang();
  const addItem = useCartStore((s) => s.addItem);
  const isLoading = useCartStore((s) => s.isLoading);

  const node = product.node;
  const image = node.images.edges[0]?.node;
  const variant =
    node.variants.edges.find((v) => v.node.availableForSale)?.node ??
    node.variants.edges[0]?.node;

  const price = node.priceRange.minVariantPrice;

  const handleAddToCart = async () => {
    if (!variant) return;
    await addItem({
      variantId: variant.id,
      variantTitle: variant.title,
      productTitle: node.title,
      handle: node.handle,
      imageUrl: image?.url ?? null,
      price: variant.price,
      quantity: 1,
      selectedOptions: variant.selectedOptions ?? [],
    });
    toast.success(t.products.added, { position: "top-center" });
  };

  return (
    <div className="group flex flex-col overflow-hidden rounded-xl border bg-card transition-shadow hover:shadow-lg">
      <Link to="/product/$handle" params={{ handle: node.handle }} className="block">
        <div className="aspect-square w-full overflow-hidden bg-secondary">
          {image ? (
            <img
              src={image.url}
              alt={image.altText ?? node.title}
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
          ) : (
            <div className="flex h-full items-center justify-center text-muted-foreground">
              <ShoppingCart className="h-10 w-10" />
            </div>
          )}
        </div>
      </Link>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <Link
          to="/product/$handle"
          params={{ handle: node.handle }}
          className="font-medium leading-snug hover:underline"
        >
          {node.title}
        </Link>
        <p className="text-lg font-bold text-primary">
          {t.products.from} {formatPrice(price.amount, price.currencyCode, lang)}
        </p>
        <Button
          onClick={handleAddToCart}
          disabled={isLoading || !variant || !variant.availableForSale}
          className="mt-auto w-full"
        >
          {isLoading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : variant?.availableForSale ? (
            t.products.addToCart
          ) : (
            t.products.soldOut
          )}
        </Button>
      </div>
    </div>
  );
}
