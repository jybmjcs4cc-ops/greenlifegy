import { useEffect, useState } from "react";
import logoVideo from "@/assets/videos/greenlife-logo-intro.mp4.asset.json";

// Plays the logo video full-screen once per browser session, then fades out.
export function IntroSplash() {
  const [show, setShow] = useState(false);
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    if (sessionStorage.getItem("intro-seen")) return;
    sessionStorage.setItem("intro-seen", "1");
    setShow(true);
    const t = setTimeout(close, 6000); // safety if video fails
    return () => clearTimeout(t);
  }, []);

  function close() {
    setLeaving(true);
    setTimeout(() => setShow(false), 500);
  }

  if (!show) return null;
  return (
    <div
      onClick={close}
      className={`fixed inset-0 z-[100] flex items-center justify-center bg-background transition-opacity duration-500 ${leaving ? "opacity-0" : "opacity-100"}`}
    >
      <video
        src={logoVideo.url}
        autoPlay
        muted
        playsInline
        onEnded={close}
        onError={close}
        className="h-full w-full object-contain"
      />
    </div>
  );
}
