export function Logo() {
  return (
    <span className="logo-root flex items-center gap-1.5" dir="ltr" aria-label="greenlife">
      <svg viewBox="0 0 32 32" className="logo-leaf h-8 w-8" aria-hidden="true">
        <path
          className="logo-leaf-fill"
          d="M6 26C6 13 15 5 27 5c0 12-8 21-21 21z"
        />
        <path className="logo-leaf-vein" d="M7 25C12 18 17 13 23 9" />
      </svg>
      <span className="font-display text-xl font-extrabold lowercase tracking-tight">
        <span className="text-foreground">green</span>
        <span className="logo-life">life</span>
      </span>
    </span>
  );
}
