import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { company } from "@/lib/company";
import { useT, useLang } from "@/lib/i18n";
import { Building2, Clock, Facebook, Instagram, Mail, MapPin, MessageCircle, Phone } from "lucide-react";

export const Route = createFileRoute("/contact")({
  component: ContactPage,
  head: () => ({
    meta: [
      { title: "بيانات الشركة | Company Info — جرين لايف للبلاستيك" },
      {
        name: "description",
        content:
          "بيانات التواصل مع الشركة: البريد الإلكتروني، أرقام التليفون، والعنوان — Company contact details: email, phone numbers and address.",
      },
      { property: "og:title", content: "بيانات الشركة | Company Info — جرين لايف للبلاستيك" },
      {
        property: "og:description",
        content: "بيانات التواصل مع الشركة — البريد الإلكتروني، أرقام التليفون، والعنوان.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

type Row = {
  icon: typeof Mail;
  label: string;
  lines: string[];
  link?: (line: string) => string | undefined;
};

const valueDir = (value: string) => (/^[\u0600-\u06FF]/.test(value) ? "rtl" : "ltr");

function ContactPage() {
  const t = useT();
  const lang = useLang();

  const rows: Row[] = [
    {
      icon: Mail,
      label: t.contact.email,
      lines: company.email ? [company.email] : [],
      link: (line) => `mailto:${line}`,
    },
    {
      icon: Phone,
      label: t.contact.phones,
      lines: company.phones,
      link: (line) => `tel:${line.replace(/[\s()-]/g, "")}`,
    },
    {
      icon: MapPin,
      label: t.contact.address,
      lines: company.address[lang] ? [company.address[lang]] : [],
    },
    {
      icon: Clock,
      label: t.contact.hours,
      lines: company.hours[lang] ? [company.hours[lang]] : [],
    },
    {
      icon: MessageCircle,
      label: t.contact.whatsapp,
      lines: company.whatsapp ? [company.whatsapp] : [],
      link: (line) => `https://wa.me/${line.replace(/\D/g, "")}`,
    },
    {
      icon: Instagram,
      label: t.contact.instagram,
      lines: company.instagram ? [`@${company.instagram}`] : [],
      link: () => `https://www.instagram.com/${company.instagram}`,
    },
    {
      icon: Facebook,
      label: t.contact.facebook,
      lines: [company.facebook.name],
      link: () => company.facebook.url,
    },
  ];

  return (
    <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6">
      <div className="flex items-center gap-3">
        <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary text-primary-foreground">
          <Building2 className="h-6 w-6" />
        </span>
        <div>
          <h1 className="font-display text-3xl font-bold">{t.contact.title}</h1>
          <p className="text-muted-foreground">{t.contact.subtitle}</p>
        </div>
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        {rows.map((row) => (
          <div key={row.label} className="flex items-start gap-4 rounded-xl border bg-card p-5">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-secondary">
              <row.icon className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-muted-foreground">{row.label}</p>
              {row.lines.length > 0 ? (
                <div className="mt-1 flex flex-col gap-1">
                  {row.lines.map((line) => {
                    const href = row.link?.(line);
                    const external = href?.startsWith("http");
                    return href ? (
                      <a
                        key={line}
                        href={href}
                        dir={valueDir(line)}
                        target={external ? "_blank" : undefined}
                        rel={external ? "noopener noreferrer" : undefined}
                        className="break-words font-medium tabular-nums underline-offset-4 hover:underline"
                      >
                        {line}
                      </a>
                    ) : (
                      <p key={line} dir={valueDir(line)} className="break-words font-medium">
                        {line}
                      </p>
                    );
                  })}
                </div>
              ) : (
                <p className="mt-1 text-sm text-muted-foreground italic">{t.contact.missing}</p>
              )}
            </div>
          </div>
        ))}
      </div>

      {company.phones.length > 0 && (
        <Button size="lg" className="mt-8" asChild>
          <a href={`tel:${company.phones[0]?.replace(/\s/g, "") ?? ""}`}>{t.contact.callUs}</a>
        </Button>
      )}
    </div>
  );
}
