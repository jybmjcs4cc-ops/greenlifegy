import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { productsQueryOptions } from "@/lib/queries";
import { ProductCard } from "@/components/ProductCard";
import { useT } from "@/lib/i18n";
import { PackageSearch } from "lucide-react";

export const Route = createFileRoute("/products")({
  loader: ({ context }) => context.queryClient.ensureQueryData(productsQueryOptions(50)),
  component: ProductsPage,
  head: () => ({
    meta: [
      { title: "المنتجات | Products — جرين لايف للبلاستيك" },
      {
        name: "description",
        content: "تشكيلة منتجات البلاستيك الكاملة بأفضل الأسعار — Full range of plastic products at the best prices.",
      },
      { property: "og:title", content: "المنتجات | Products — جرين لايف للبلاستيك" },
      {
        property: "og:description",
        content: "تشكيلة منتجات البلاستيك الكاملة بأفضل الأسعار.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function ProductsPage() {
  const t = useT();
  const { data: products } = useSuspenseQuery(productsQueryOptions(50));

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <h1 className="font-display text-3xl font-bold">{t.products.title}</h1>
      <p className="mt-1 text-muted-foreground">{t.products.subtitle}</p>

      {products.length === 0 ? (
        <div className="mt-10 flex flex-col items-center justify-center rounded-xl border border-dashed py-24 text-center">
          <PackageSearch className="h-12 w-12 text-muted-foreground" />
          <p className="mt-4 text-lg font-semibold">{t.products.empty}</p>
          <p className="mt-1 text-sm text-muted-foreground">{t.products.emptyHint}</p>
        </div>
      ) : (
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {products.map((product) => (
            <ProductCard key={product.node.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
}
