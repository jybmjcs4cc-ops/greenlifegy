import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { useT } from "@/lib/i18n";
import { Package2, ShoppingCart } from "lucide-react";
import type { CSSProperties } from "react";

export const Route = createFileRoute("/palettes")({
  component: PalettesPage,
  head: () => ({
    meta: [
      { title: "اختيار الألوان | GreenLife Plastics" },
      { name: "description", content: "اختيارات ألوان متجر جرين لايف للبلاستيك." },
      { property: "og:title", content: "اختيار الألوان | GreenLife Plastics" },
      { property: "og:description", content: "اختيارات ألوان متجر جرين لايف للبلاستيك." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
});

/* ---------- tiny color helpers (hex only, no dependencies) ---------- */

function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  return [
    parseInt(h.slice(0, 2), 16),
    parseInt(h.slice(2, 4), 16),
    parseInt(h.slice(4, 6), 16),
  ];
}

function rgbToHex(r: number, g: number, b: number): string {
  const c = (n: number) =>
    Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, "0");
  return `#${c(r)}${c(g)}${c(b)}`;
}

/** mix `a` toward `b` by amount 0..1 */
function mix(a: string, b: string, amount: number): string {
  const [r1, g1, b1] = hexToRgb(a);
  const [r2, g2, b2] = hexToRgb(b);
  return rgbToHex(
    r1 + (r2 - r1) * amount,
    g1 + (g2 - g1) * amount,
    b1 + (b2 - b1) * amount,
  );
}

function channelLum(v: number): number {
  const c = v / 255;
  return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
}

/** pick black or white text so the badge/CTA label stays readable */
function readableOn(hex: string): string {
  const [r, g, b] = hexToRgb(hex);
  const lum =
    0.2126 * channelLum(r) + 0.7152 * channelLum(g) + 0.0722 * channelLum(b);
  const contrastWithWhite = (lum + 0.05) / 0.06;
  const contrastWithBlack = (lum + 0.05) / 0.011;
  return contrastWithBlack >= contrastWithWhite ? "#1c1a17" : "#ffffff";
}

/* ---------------------------- palettes ---------------------------- */

type Palette = {
  id: number;
  name: string;
  dark: string;
  bright: string;
};

const PALETTES: Palette[] = [
  { id: 1, name: "أخضر غامق + ذهبي", dark: "#0B3D2E", bright: "#E3A857" },
  { id: 2, name: "بترولي + برتقالي", dark: "#0A4550", bright: "#F2793B" },
  { id: 3, name: "كحلي + أصفر زعفراني", dark: "#101F42", bright: "#F2B705" },
  { id: 4, name: "فحمي + نعناعي", dark: "#23282B", bright: "#7FD1B9" },
  { id: 5, name: "نبيتي + برتقالي هادي", dark: "#4A1533", bright: "#E8845E" },
  { id: 6, name: "أزرق ملكي + مرجاني", dark: "#123A75", bright: "#FF6B5B" },
  { id: 7, name: "بني قهوة + كراميل", dark: "#3A2418", bright: "#D9A566" },
  { id: 8, name: "بنفسجي غامق + ليموني", dark: "#2E1065", bright: "#C6F24E" },
  { id: 9, name: "زيتي + خردلي", dark: "#33401A", bright: "#E0B41C" },
  { id: 10, name: "رمادي حجري + أحمر", dark: "#2B2F36", bright: "#D64545" },
  { id: 11, name: "تركواز + وردي", dark: "#0C5C63", bright: "#FF7FA8" },
  { id: 12, name: "أسود + أخضر فلوري", dark: "#101211", bright: "#A3E635" },
];

function varsFor(p: Palette): CSSProperties {
  const { dark, bright } = p;
  const foreground = mix(dark, "#000000", 0.3);
  return {
    "--background": mix(dark, "#ffffff", 0.965),
    "--foreground": foreground,
    "--card": "#ffffff",
    "--card-foreground": foreground,
    "--popover": "#ffffff",
    "--popover-foreground": foreground,
    "--primary": dark,
    "--primary-foreground": mix(dark, "#ffffff", 0.96),
    "--secondary": mix(dark, "#ffffff", 0.92),
    "--secondary-foreground": foreground,
    "--muted": mix(dark, "#ffffff", 0.9),
    "--muted-foreground": mix(dark, "#ffffff", 0.5),
    "--accent": bright,
    "--accent-foreground": readableOn(bright),
    "--border": mix(dark, "#ffffff", 0.85),
    "--input": mix(dark, "#ffffff", 0.82),
    "--ring": bright,
    "--forest": dark,
    "--pine": dark,
    "--leaf": bright,
    "--lime-bright": bright,
  } as CSSProperties;
}

/* --------------------------- mini preview --------------------------- */

function MiniSite({ palette }: { palette: Palette }) {
  const t = useT();
  const demoProducts = ["كوب بلاستيك", "علبة تخزين", "صينية تقديم"];

  return (
    <div style={varsFor(palette)} className="bg-background text-foreground">
      <div className="h-1 w-full bg-accent" />

      <div className="flex items-center gap-2 border-b bg-card px-4 py-3">
        <span className="flex h-7 w-7 items-center justify-center rounded-md bg-primary text-primary-foreground">
          <Package2 className="h-4 w-4" />
        </span>
        <span className="font-display text-sm font-bold">{t.brandName}</span>
        <div className="mx-auto flex gap-1">
          {[t.nav.home, t.nav.products, t.nav.contact].map((label, i) => (
            <span
              key={label}
              className={
                i === 0
                  ? "rounded-md bg-secondary px-2 py-1 text-xs font-semibold"
                  : "rounded-md px-2 py-1 text-xs text-muted-foreground"
              }
            >
              {label}
            </span>
          ))}
        </div>
      </div>

      <div className="relative overflow-hidden bg-forest px-4 py-8 text-center text-primary-foreground">
        <span className="inline-block rounded-full bg-accent px-3 py-1 text-[11px] font-bold text-accent-foreground">
          {t.hero.badge}
        </span>
        <h3 className="mx-auto mt-3 max-w-md font-display text-xl font-extrabold">
          {t.hero.title}
        </h3>
        <p className="mx-auto mt-2 max-w-sm text-xs opacity-75">
          {t.hero.subtitle}
        </p>
        <div className="mt-4 flex flex-wrap justify-center gap-2">
          <Button size="sm" className="bg-accent font-bold text-accent-foreground">
            {t.hero.ctaPrimary}
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="border-primary-foreground/30 bg-transparent text-primary-foreground"
          >
            {t.hero.ctaSecondary}
          </Button>
        </div>
      </div>

      <div className="px-4 py-5">
        <div className="grid grid-cols-3 gap-3">
          {demoProducts.map((name) => (
            <div
              key={name}
              className="flex flex-col overflow-hidden rounded-lg border bg-card"
            >
              <div className="flex aspect-square items-center justify-center bg-secondary">
                <ShoppingCart className="h-6 w-6 text-muted-foreground" />
              </div>
              <div className="flex flex-1 flex-col gap-1 p-2">
                <span className="text-xs font-medium leading-snug">{name}</span>
                <span className="text-sm font-bold text-primary">٤٥ ج.م</span>
                <Button size="sm" className="mt-auto w-full text-xs">
                  {t.products.addToCart}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="border-t bg-secondary px-4 py-3 text-[11px] text-muted-foreground">
        {t.footer.contactUs} — ٠١١٤ ١٧٦ ٦٧٠٠
      </div>
    </div>
  );
}

/* ------------------------------ page ------------------------------ */

function PalettesPage() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <header className="rounded-2xl border bg-card p-6">
        <h1 className="font-display text-3xl font-extrabold">
          اختار الألوان اللي تعجبك
        </h1>
        <p className="mt-2 text-muted-foreground">
          كل كارت تحت هو شكل موقعك الحقيقي بلونين مختلفين. قولّي رقم التنسيقة
          اللي عاجباك وأنا أطبّقه على كل الصفحات.
        </p>
      </header>

      <div className="mt-8 grid gap-8 lg:grid-cols-2">
        {PALETTES.map((p) => (
          <section key={p.id} className="overflow-hidden rounded-2xl border shadow-sm">
            <div className="flex items-center gap-3 border-b bg-muted/40 px-4 py-3">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                {p.id}
              </span>
              <span className="font-display font-bold">{p.name}</span>
              <span className="ms-auto flex gap-1.5">
                <span
                  className="h-5 w-5 rounded-full border"
                  style={{ background: p.dark }}
                />
                <span
                  className="h-5 w-5 rounded-full border"
                  style={{ background: p.bright }}
                />
              </span>
            </div>
            <MiniSite palette={p} />
          </section>
        ))}
      </div>
    </div>
  );
}
