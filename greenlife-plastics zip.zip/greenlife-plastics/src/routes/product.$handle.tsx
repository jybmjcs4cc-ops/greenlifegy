import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { productQueryOptions } from "@/lib/queries";
import { Button } from "@/components/ui/button";
import { useCartStore } from "@/stores/cartStore";
import { formatPrice } from "@/lib/shopify";
import { useT, useLang } from "@/lib/i18n";
import { toast } from "sonner";
import { ArrowRight, Loader2, PackageSearch } from "lucide-react";

export const Route = createFileRoute("/product/$handle")({
  loader: ({ context, params }) =>
    context.queryClient.ensureQueryData(productQueryOptions(params.handle)),
  component: ProductDetail,
  head: ({ loaderData }) => {
    const title = loaderData?.title
      ? `${loaderData.title} — جرين لايف للبلاستيك`
      : "Product — جرين لايف للبلاستيك";
    return {
      meta: [
        { title },
        {
          name: "description",
          content: loaderData?.description?.slice(0, 160) ?? "تفاصيل المنتج — Product details.",
        },
        { property: "og:title", content: title },
        { property: "og:description", content: loaderData?.description?.slice(0, 160) ?? "تفاصيل المنتج — Product details." },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
});

function ProductDetail() {
  const { handle } = Route.useParams();
  const t = useT();
  const lang = useLang();
  const { data: product } = useSuspenseQuery(productQueryOptions(handle));
  const addItem = useCartStore((s) => s.addItem);
  const isLoading = useCartStore((s) => s.isLoading);
  const [quantity, setQuantity] = useState(1);
  const [selection, setSelection] = useState<Record<string, string>>({});

  if (!product) {
    return (
      <div className="mx-auto flex max-w-7xl flex-col items-center px-4 py-24 text-center sm:px-6">
        <PackageSearch className="h-12 w-12 text-muted-foreground" />
        <p className="mt-4 text-lg font-semibold">{t.products.empty}</p>
        <Button className="mt-6" variant="outline" asChild>
          <Link to="/products">{t.products.backToProducts}</Link>
        </Button>
      </div>
    );
  }

  const images = product.images.edges.map((e) => e.node);
  const variants = product.variants.edges.map((e) => e.node);

  const selectedVariant =
    Object.keys(selection).length === 0
      ? variants.find((v) => v.availableForSale) ?? variants[0]
      : variants.find((v) =>
          (v.selectedOptions ?? []).every((o) => selection[o.name] === o.value)
        );

  const handleAddToCart = async () => {
    if (!selectedVariant) return;
    await addItem({
      variantId: selectedVariant.id,
      variantTitle: selectedVariant.title,
      productTitle: product.title,
      handle: product.handle,
      imageUrl: images[0]?.url ?? null,
      price: selectedVariant.price,
      quantity,
      selectedOptions: selectedVariant.selectedOptions ?? [],
    });
    toast.success(t.products.added, { position: "top-center" });
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
      <Link
        to="/products"
        className="mb-6 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowRight className="h-4 w-4 rtl:rotate-180" />
        {t.products.backToProducts}
      </Link>

      <div className="grid gap-10 lg:grid-cols-2">
        <div className="space-y-4">
          <div className="aspect-square w-full overflow-hidden rounded-xl border bg-secondary">
            {images[0] ? (
              <img
                src={images[0].url}
                alt={images[0].altText ?? product.title}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full items-center justify-center">
                <PackageSearch className="h-16 w-16 text-muted-foreground" />
              </div>
            )}
          </div>
          {images.length > 1 && (
            <div className="grid grid-cols-4 gap-3">
              {images.slice(1, 5).map((img, i) => (
                <div key={i} className="aspect-square overflow-hidden rounded-lg border bg-secondary">
                  <img src={img.url} alt={img.altText ?? product.title} className="h-full w-full object-cover" />
                </div>
              ))}
            </div>
          )}
        </div>

        <div>
          <h1 className="font-display text-3xl font-bold">{product.title}</h1>
          {selectedVariant && (
            <p className="mt-3 text-2xl font-bold text-primary">
              {formatPrice(selectedVariant.price.amount, selectedVariant.price.currencyCode, lang)}
            </p>
          )}
          {!selectedVariant?.availableForSale && (
            <p className="mt-2 text-sm font-semibold text-destructive">{t.products.soldOut}</p>
          )}

          {product.options.length > 0 && product.options.some((o) => o.values.length > 1) && (
            <div className="mt-6 space-y-4">
              <h3 className="text-sm font-semibold text-muted-foreground">{t.products.options}</h3>
              {product.options
                .filter((o) => o.values.length > 1)
                .map((option) => (
                  <div key={option.name}>
                    <p className="mb-1.5 text-sm font-medium">{option.name}</p>
                    <div className="flex flex-wrap gap-2">
                      {option.values.map((value) => {
                        const selected = selection[option.name] === value;
                        return (
                          <button
                            key={value}
                            type="button"
                            onClick={() => setSelection((s) => ({ ...s, [option.name]: value }))}
                            className={
                              "rounded-md border px-3 py-1.5 text-sm transition-colors " +
                              (selected
                                ? "border-primary bg-primary text-primary-foreground"
                                : "bg-background hover:bg-secondary")
                            }
                          >
                            {value}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
            </div>
          )}

          <div className="mt-6 flex items-center gap-3">
            <span className="text-sm font-medium">{t.products.quantity}</span>
            <div className="flex items-center rounded-md border">
              <button
                type="button"
                className="px-3 py-1.5 text-lg"
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
              >
                −
              </button>
              <span className="w-10 text-center text-sm font-semibold">{quantity}</span>
              <button
                type="button"
                className="px-3 py-1.5 text-lg"
                onClick={() => setQuantity((q) => q + 1)}
              >
                +
              </button>
            </div>
          </div>

          <Button
            size="lg"
            className="mt-6 w-full sm:w-auto"
            onClick={handleAddToCart}
            disabled={isLoading || !selectedVariant || !selectedVariant.availableForSale}
          >
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : t.products.addToCart}
          </Button>

          {product.description && (
            <div className="mt-8 border-t pt-6">
              <h3 className="text-sm font-semibold text-muted-foreground">
                {t.products.description}
              </h3>
              <p className="mt-2 whitespace-pre-line leading-relaxed text-muted-foreground">
                {product.description}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
