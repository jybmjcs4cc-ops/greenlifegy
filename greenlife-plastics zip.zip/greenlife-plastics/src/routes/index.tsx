import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { productsQueryOptions } from "@/lib/queries";
import { ProductCard } from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { useT } from "@/lib/i18n";
import { PackageSearch } from "lucide-react";

export const Route = createFileRoute("/")({
  loader: ({ context }) => context.queryClient.ensureQueryData(productsQueryOptions(8)),
  component: Index,
  head: () => ({
    meta: [
      {
        title: "جرين لايف للبلاستيك | GreenLife Plastics",
      },
      {
        name: "description",
        content:
          "متجر منتجات بلاستيك بأسعار مناسبة — عربي وإنجليزي. Plastic products store with great prices, Arabic and English.",
      },
      { property: "og:title", content: "جرين لايف للبلاستيك | GreenLife Plastics" },
      {
        property: "og:description",
        content: "منتجات عالية الجودة بأسعار مناسبة — اطلب أونلاين.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function Index() {
  const t = useT();
  const { data: products } = useSuspenseQuery(productsQueryOptions(8));

  return (
    <div>
      <section className="relative overflow-hidden border-b bg-forest text-primary-foreground">
        <div className="grid-pattern absolute inset-0 opacity-10" />
        <div className="absolute -top-32 left-1/4 h-96 w-96 rounded-full bg-leaf/20 blur-3xl" />
        <div className="absolute -bottom-40 right-1/4 h-96 w-96 rounded-full bg-lime-bright/10 blur-3xl" />
        <div className="relative mx-auto max-w-7xl px-4 py-20 text-center sm:px-6 sm:py-28">
          <span className="inline-block rounded-full bg-accent px-4 py-1.5 text-sm font-bold text-accent-foreground shadow-lg">
            {t.hero.badge}
          </span>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-4xl font-extrabold tracking-tight sm:text-6xl">
            {t.hero.title}
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-primary-foreground/75 sm:text-lg">
            {t.hero.subtitle}
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Button size="lg" className="bg-accent font-bold text-accent-foreground hover:bg-accent/90" asChild>
              <Link to="/products">{t.hero.ctaPrimary}</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-primary-foreground/30 bg-transparent text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground"
              asChild
            >
              <Link to="/contact">{t.hero.ctaSecondary}</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="font-display text-3xl font-bold">{t.products.title}</h2>
            <p className="mt-1 text-muted-foreground">{t.products.subtitle}</p>
          </div>
          <Button variant="outline" asChild>
            <Link to="/products">{t.products.viewAll}</Link>
          </Button>
        </div>

        {products.length === 0 ? (
          <div className="mt-10 flex flex-col items-center justify-center rounded-xl border border-dashed py-20 text-center">
            <PackageSearch className="h-12 w-12 text-muted-foreground" />
            <p className="mt-4 text-lg font-semibold">{t.products.empty}</p>
            <p className="mt-1 text-sm text-muted-foreground">{t.products.emptyHint}</p>
          </div>
        ) : (
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {products.map((product) => (
              <ProductCard key={product.node.id} product={product} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
