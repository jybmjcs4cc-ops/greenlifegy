// Company details shown on the site. Update these values once the real
// business information is provided — nothing else needs to change.
export const company = {
  name: { ar: "جرين لايف للبلاستيك", en: "GreenLife Plastics" },
  email: "",
  phones: ["+20 114 1766700", "+20 114 1889985"],
  whatsapp: "",
  address: {
    ar: "القاهرة - المنطقة الصناعية الثالثة، العاشر من رمضان، A5",
    en: "Cairo - Tenth of Ramadan 3rd Industrial Zone A5",
  },
  hours: { ar: "", en: "" },
  instagram: "greenlife_plastics",
  facebook: {
    name: "GreenLife Plastics",
    url: "https://www.facebook.com/search/top?q=greenlife%20plastics",
  },
};
