import { queryOptions } from "@tanstack/react-query";
import { fetchProducts, fetchProductByHandle } from "@/lib/shopify";

export const productsQueryOptions = (first: number, query?: string) =>
  queryOptions({
    queryKey: ["shopify", "products", first, query ?? null],
    queryFn: async () => {
      try {
        return await fetchProducts(first, query);
      } catch (error) {
        console.error("Failed to load products:", error);
        return [];
      }
    },
  });

export const productQueryOptions = (handle: string) =>
  queryOptions({
    queryKey: ["shopify", "product", handle],
    queryFn: async () => {
      try {
        return await fetchProductByHandle(handle);
      } catch (error) {
        console.error("Failed to load product:", error);
        return null;
      }
    },
  });
