import { useEffect } from "react";
import { create } from "zustand";

export type Lang = "ar" | "en";

interface LangStore {
  lang: Lang;
  setLang: (lang: Lang) => void;
}

export const useLangStore = create<LangStore>((set) => ({
  lang: "ar",
  setLang: (lang) => set({ lang }),
}));

const ar = {
  brandName: "جرين لايف للبلاستيك",
  nav: {
    home: "الرئيسية",
    products: "المنتجات",
    contact: "بيانات الشركة",
  },
  hero: {
    badge: "منتجات عالية الجودة",
    title: "كل احتياجات البلاستيك في مكان واحد",
    subtitle:
      "تشكيلة واسعة من منتجات البلاستيك بأسعار مناسبة — اطلب أونلاين واستلم بسهولة.",
    ctaPrimary: "تسوق الآن",
    ctaSecondary: "تواصل معنا",
  },
  products: {
    title: "المنتجات",
    subtitle: "أفضل الأسعار على تشكيلة البلاستيك الكاملة",
    viewAll: "شاهد كل المنتجات",
    empty: "لا توجد منتجات بعد",
    emptyHint: "أضف منتجاتك من لوحة التحكم أو أخبرنا بالمنتجات والأسعار.",
    addToCart: "أضف للسلة",
    added: "تمت الإضافة للسلة",
    from: "يبدأ من",
    soldOut: "غير متوفر",
    quantity: "الكمية",
    description: "الوصف",
    options: "الخيارات",
    backToProducts: "كل المنتجات",
    addOne: "أضف قطعة",
  },
  cart: {
    title: "سلة التسوق",
    emptyTitle: "سلتك فارغة",
    emptyDesc: "أضف منتجات لتبدأ الطلب",
    total: "الإجمالي",
    checkout: "إتمام الشراء",
    items: "منتج",
  },
  contact: {
    title: "بيانات الشركة",
    subtitle: "تواصل معنا في أي وقت — نحن هنا لخدمتك",
    email: "البريد الإلكتروني",
    phones: "أرقام التليفون",
    address: "العنوان",
    hours: "مواعيد العمل",
    whatsapp: "واتساب",
    instagram: "إنستجرام",
    facebook: "فيسبوك",
    callUs: "اتصل بنا",
    missing: "سيتم إضافتها قريباً",
  },
  footer: {
    rights: "جميع الحقوق محفوظة",
    quickLinks: "روابط سريعة",
    contactUs: "تواصل معنا",
  },
  langLabel: "EN",
};

export type Dictionary = typeof ar;

const en: Dictionary = {
  brandName: "GreenLife Plastics",
  nav: {
    home: "Home",
    products: "Products",
    contact: "Company Info",
  },
  hero: {
    badge: "High-quality plastic products",
    title: "All your plastic needs in one place",
    subtitle:
      "A wide range of plastic products at great prices — order online with ease.",
    ctaPrimary: "Shop Now",
    ctaSecondary: "Contact Us",
  },
  products: {
    title: "Products",
    subtitle: "Best prices on our full plastic range",
    viewAll: "View all products",
    empty: "No products yet",
    emptyHint: "Add products from the dashboard or tell us the products and prices.",
    addToCart: "Add to Cart",
    added: "Added to cart",
    from: "From",
    soldOut: "Sold out",
    quantity: "Quantity",
    description: "Description",
    options: "Options",
    backToProducts: "All products",
    addOne: "Add one",
  },
  cart: {
    title: "Shopping Cart",
    emptyTitle: "Your cart is empty",
    emptyDesc: "Add products to start your order",
    total: "Total",
    checkout: "Checkout",
    items: "items",
  },
  contact: {
    title: "Company Information",
    subtitle: "Reach out any time — we are here to serve you",
    email: "Email",
    phones: "Phone Numbers",
    address: "Address",
    hours: "Working Hours",
    whatsapp: "WhatsApp",
    instagram: "Instagram",
    facebook: "Facebook",
    callUs: "Call us",
    missing: "Coming soon",
  },
  footer: {
    rights: "All rights reserved",
    quickLinks: "Quick Links",
    contactUs: "Contact Us",
  },
  langLabel: "عربي",
};

const dictionaries: Record<Lang, Dictionary> = { ar, en };

export function useT(): Dictionary {
  return dictionaries[useLangStore((s) => s.lang)];
}

export function useLang(): Lang {
  return useLangStore((s) => s.lang);
}

export function LangEffects() {
  const lang = useLangStore((s) => s.lang);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    try {
      localStorage.setItem("app-lang", lang);
    } catch {
      // ignore storage failures
    }
  }, [lang]);

  return null;
}
